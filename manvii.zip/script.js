document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const expressionDisplay = document.querySelector('.expression');
    const resultDisplay = document.querySelector('.result');
    const buttons = document.querySelectorAll('button');
    
    // Calculator state
    let currentExpression = '';
    let currentResult = '0';
    let memory = 0;
    let isInRadMode = true;
    let waitingForOperand = false;
    
    // Initialize display
    updateDisplay();
    
    // Add event listeners to all buttons
    buttons.forEach(button => {
        button.addEventListener('click', () => handleButtonClick(button.dataset.value));
    });
    
    // Handle keyboard input
    document.addEventListener('keydown', handleKeydown);
    
    function handleKeydown(e) {
        const key = e.key;
        
        if (/[0-9.]/.test(key)) {
            handleButtonClick(key);
        } else if (key === '+' || key === '-' || key === '*' || key === '/') {
            handleButtonClick(key);
        } else if (key === 'Enter' || key === '=') {
            handleButtonClick('=');
        } else if (key === 'Backspace') {
            handleButtonClick('clear');
        } else if (key === 'Escape') {
            handleButtonClick('AC');
        } else if (key === '(' || key === ')') {
            handleButtonClick(key);
        }
    }
    
    function handleButtonClick(value) {
        switch (value) {
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
            case '.':
                handleNumber(value);
                break;
            case '+':
            case '-':
            case '*':
            case '/':
                handleOperator(value);
                break;
            case '=':
                calculate();
                break;
            case 'clear':
                clearEntry();
                break;
            case 'AC':
                allClear();
                break;
            case '+/-':
                toggleSign();
                break;
            case '%':
                percentage();
                break;
            case 'sin':
                trigFunction('sin');
                break;
            case 'cos':
                trigFunction('cos');
                break;
            case 'tan':
                trigFunction('tan');
                break;
            case 'sinh':
                trigFunction('sinh');
                break;
            case 'cosh':
                trigFunction('cosh');
                break;
            case 'tanh':
                trigFunction('tanh');
                break;
            case 'ln':
                logarithm('ln');
                break;
            case 'log':
                logarithm('log');
                break;
            case 'sqrt':
                squareRoot();
                break;
            case 'cbrt':
                cubeRoot();
                break;
            case 'x^2':
                square();
                break;
            case 'x^3':
                cube();
                break;
            case 'x^y':
                power();
                break;
            case 'e^x':
                exponentE();
                break;
            case '10^x':
                exponent10();
                break;
            case '1/x':
                reciprocal();
                break;
            case 'fact':
                factorial();
                break;
            case 'pi':
                addPi();
                break;
            case 'e':
                addE();
                break;
            case 'rad':
                toggleAngleMode();
                break;
            case 'rand':
                random();
                break;
            case '(':
            case ')':
                addParenthesis(value);
                break;
            case 'mc':
                memoryClear();
                break;
            case 'm+':
                memoryAdd();
                break;
            case 'm-':
                memorySubtract();
                break;
            case 'mr':
                memoryRecall();
                break;
            case 'mod':
                handleOperator('%');
                break;
            case 'EE':
                addScientificNotation();
                break;
            case 'exp':
                addExponential();
                break;
            case 'root':
                nthRoot();
                break;
            case 'log_y':
                logBase();
                break;
        }
        
        updateDisplay();
    }
    
    function handleNumber(value) {
        if (waitingForOperand) {
            currentResult = value;
            waitingForOperand = false;
        } else {
            if (currentResult === '0' && value !== '.') {
                currentResult = value;
            } else {
                // Prevent multiple decimal points
                if (value === '.' && currentResult.includes('.')) {
                    return;
                }
                currentResult += value;
            }
        }
    }
    
    function handleOperator(operator) {
        // If we already have an operator in the expression, calculate the result first
        if (!waitingForOperand) {
            currentExpression += currentResult;
        }
        
        // Add the operator
        currentExpression += ` ${operator} `;
        waitingForOperand = true;
    }
    
    function calculate() {
        if (!currentExpression && currentResult !== '0' && currentResult !== 'Error') {
            return;
        }
        
        try {
            // Create the final expression to evaluate
            let finalExpression = currentExpression;
            if (!waitingForOperand) {
                finalExpression += currentResult;
            } else {
                // If ending with an operator, remove it
                finalExpression = finalExpression.trim().replace(/[\+\-\*\/\%\^]\s*$/, '');
            }
            
            // Check for balanced parentheses
            const openParens = (finalExpression.match(/\(/g) || []).length;
            const closeParens = (finalExpression.match(/\)/g) || []).length;
            
            // Add closing parentheses if needed
            if (openParens > closeParens) {
                finalExpression += ')'.repeat(openParens - closeParens);
            }
            
            // Replace visual operators with JavaScript operators
            finalExpression = finalExpression
                .replace(/×/g, '*')
                .replace(/÷/g, '/')
                .replace(/\s/g, '')
                .replace(/%/g, '/100')
                .replace(/mod/g, '%');
            
            // Safely evaluate the expression
            const result = safeEval(finalExpression);
            
            // Update displays
            currentExpression = '';
            currentResult = formatResult(result);
            waitingForOperand = true;
            
        } catch (error) {
            currentResult = 'Error';
            currentExpression = '';
            waitingForOperand = true;
        }
    }
    
    // Helper function to safely evaluate mathematical expressions
    function safeEval(expression) {
        // Replace constants
        expression = expression.replace(/π/g, 'Math.PI').replace(/e(?![^(]*\))/g, 'Math.E');
        
        // Handle special operators
        expression = expression
            // Replace ^ with Math.pow - handle numbers, parentheses, and constants
            .replace(/(\d+\.?\d*|Math\.PI|Math\.E|\))\s*\^\s*(\d+\.?\d*|Math\.PI|Math\.E|\()/g, 'Math.pow($1, $2)')
            
            // Handle nth root: a root b => Math.pow(b, 1/a)
            .replace(/(\d+\.?\d*|Math\.PI|Math\.E|\))\s*root\s*(\d+\.?\d*|Math\.PI|Math\.E|\()/g, 'Math.pow($2, 1/$1)')
            
            // Handle log base y: log(x, y) => Math.log(y) / Math.log(x)
            .replace(/log\((\d+\.?\d*|Math\.PI|Math\.E|\([^,]*\)),\s*(\d+\.?\d*|Math\.PI|Math\.E|\([^)]*\))\)/g, '(Math.log($2) / Math.log($1))');
        
        // Create a function that evaluates the expression in a controlled scope
        return Function('"use strict"; return (' + expression + ')')();
    }
    
    function clearEntry() {
        currentResult = '0';
    }
    
    function allClear() {
        currentExpression = '';
        currentResult = '0';
        waitingForOperand = false;
    }
    
    function toggleSign() {
        currentResult = (parseFloat(currentResult) * -1).toString();
    }
    
    function percentage() {
        const value = parseFloat(currentResult);
        currentResult = (value / 100).toString();
    }
    
    function trigFunction(func) {
        let value = parseFloat(currentResult);
        
        // Convert to radians if in degree mode
        if (!isInRadMode) {
            value = value * Math.PI / 180;
        }
        
        switch (func) {
            case 'sin':
                currentResult = Math.sin(value).toString();
                break;
            case 'cos':
                currentResult = Math.cos(value).toString();
                break;
            case 'tan':
                currentResult = Math.tan(value).toString();
                break;
            case 'sinh':
                currentResult = Math.sinh(value).toString();
                break;
            case 'cosh':
                currentResult = Math.cosh(value).toString();
                break;
            case 'tanh':
                currentResult = Math.tanh(value).toString();
                break;
        }
        
        waitingForOperand = true;
    }
    
    function logarithm(type) {
        const value = parseFloat(currentResult);
        if (value <= 0) {
            currentResult = 'Error';
            return;
        }
        
        if (type === 'ln') {
            currentResult = Math.log(value).toString();
        } else {
            currentResult = Math.log10(value).toString();
        }
        
        waitingForOperand = true;
    }
    
    function squareRoot() {
        const value = parseFloat(currentResult);
        if (value < 0) {
            currentResult = 'Error';
            return;
        }
        
        currentResult = Math.sqrt(value).toString();
        waitingForOperand = true;
    }
    
    function cubeRoot() {
        const value = parseFloat(currentResult);
        currentResult = Math.cbrt(value).toString();
        waitingForOperand = true;
    }
    
    function square() {
        const value = parseFloat(currentResult);
        currentResult = (value * value).toString();
        waitingForOperand = true;
    }
    
    function cube() {
        const value = parseFloat(currentResult);
        currentResult = (value * value * value).toString();
        waitingForOperand = true;
    }
    
    function power() {
        if (waitingForOperand) {
            // If we're waiting for an operand, replace the last operator
            currentExpression = currentExpression.replace(/\s*[\+\-\*\/\%\^]\s*$/, ' ^ ');
        } else {
            currentExpression += currentResult + ' ^ ';
            waitingForOperand = true;
        }
    }
    
    function exponentE() {
        const value = parseFloat(currentResult);
        currentResult = Math.exp(value).toString();
        waitingForOperand = true;
    }
    
    function exponent10() {
        const value = parseFloat(currentResult);
        currentResult = Math.pow(10, value).toString();
        waitingForOperand = true;
    }
    
    function reciprocal() {
        const value = parseFloat(currentResult);
        if (value === 0) {
            currentResult = 'Error';
            return;
        }
        
        currentResult = (1 / value).toString();
        waitingForOperand = true;
    }
    
    function factorial() {
        const num = parseInt(currentResult);
        if (num < 0 || !Number.isInteger(num)) {
            currentResult = 'Error';
            return;
        }
        
        let result = 1;
        for (let i = 2; i <= num; i++) {
            result *= i;
        }
        
        currentResult = result.toString();
        waitingForOperand = true;
    }
    
    function addPi() {
        currentResult = Math.PI.toString();
        waitingForOperand = false;
    }
    
    function addE() {
        currentResult = Math.E.toString();
        waitingForOperand = false;
    }
    
    function toggleAngleMode() {
        isInRadMode = !isInRadMode;
        document.querySelector('[data-value="rad"]').textContent = isInRadMode ? 'Rad' : 'Deg';
    }
    
    function random() {
        currentResult = Math.random().toString();
        waitingForOperand = false;
    }
    
    function addParenthesis(parenthesis) {
        if (waitingForOperand || currentResult === '0') {
            currentExpression += parenthesis;
        } else {
            currentExpression += currentResult + parenthesis;
            waitingForOperand = true;
        }
    }
    
    function memoryClear() {
        memory = 0;
    }
    
    function memoryAdd() {
        memory += parseFloat(currentResult);
    }
    
    function memorySubtract() {
        memory -= parseFloat(currentResult);
    }
    
    function memoryRecall() {
        currentResult = memory.toString();
        waitingForOperand = false;
    }
    
    function addScientificNotation() {
        currentResult += 'e';
    }
    
    function addExponential() {
        currentResult = parseFloat(currentResult).toExponential();
        waitingForOperand = false;
    }
    
    function nthRoot() {
        if (waitingForOperand) {
            // If we're waiting for an operand, replace the last operator
            currentExpression = currentExpression.replace(/\s*[\+\-\*\/\%\^]\s*$/, ' root ');
        } else {
            currentExpression += currentResult + ' root ';
            waitingForOperand = true;
        }
    }
    
    function logBase() {
        if (waitingForOperand) {
            // If we're waiting for an operand, update the expression
            currentExpression = currentExpression.trim();
            if (currentExpression.endsWith(',')) {
                currentExpression += ' ';
            } else {
                currentExpression += 'log(';
            }
        } else {
            // Start a new log base expression
            currentExpression += 'log(' + currentResult + ', ';
            waitingForOperand = true;
        }
    }
    
    function updateDisplay() {
        expressionDisplay.textContent = currentExpression;
        resultDisplay.textContent = currentResult;
    }
    
    function formatResult(result) {
        // Convert result to string and handle potential precision issues
        if (typeof result === 'number') {
            // Handle very small numbers near zero
            if (Math.abs(result) < 1e-10 && result !== 0) {
                return result.toExponential(10);
            }
            
            // Handle large numbers
            if (Math.abs(result) > 1e15) {
                return result.toExponential(10);
            }
            
            // For "normal" numbers, limit decimal places to avoid floating point errors
            const resultStr = result.toString();
            if (resultStr.includes('.') && resultStr.split('.')[1].length > 10) {
                return result.toFixed(10).replace(/\.?0+$/, '');
            }
            
            return resultStr;
        }
        
        return result.toString();
    }
}); 